#!/bin/bash
# Run this once locally to generate the gradle wrapper
gradle wrapper --gradle-version 8.4 --distribution-type bin

# 🌿 MoodSync

Application Android de suivi d'humeur avec intégration SMS, appels et notifications.

[![Build APK](https://github.com/VOTRE_USERNAME/MoodSync/actions/workflows/build.yml/badge.svg)](https://github.com/VOTRE_USERNAME/MoodSync/actions/workflows/build.yml)

## ✨ Fonctionnalités

| Fonctionnalité | Description |
|---|---|
| 🌿 **Journal d'humeur** | 8 états émotionnels, notes, niveau d'énergie, tags |
| 🔔 **Notifications** | Lecture de toutes les notifs avec snapshot d'humeur |
| 💬 **SMS** | Envoi de SMS + réponses rapides + recherche contacts |
| 📞 **Appels** | Journal d'appels entrants/manqués/sortants + numéroteur |
| 📊 **Statistiques** | Distribution, streak, corrélations activité/humeur |

## 🚀 Build & Installation

### Via GitHub Actions (recommandé)
1. Fork ce dépôt
2. Chaque push sur `main` génère automatiquement un APK
3. Téléchargez l'APK dans **Actions > Build MoodSync APK > Artifacts**
4. Ou récupérez la dernière **Release** avec l'APK attaché

### Build local
```bash
# Cloner
git clone https://github.com/VOTRE_USERNAME/MoodSync.git
cd MoodSync

# Générer le wrapper Gradle (première fois)
gradle wrapper --gradle-version 8.4

# Build
./gradlew assembleDebug

# APK généré ici :
# app/build/outputs/apk/debug/app-debug.apk
```

## 📋 Permissions requises

| Permission | Utilisation |
|---|---|
| `RECEIVE_SMS` / `READ_SMS` / `SEND_SMS` | Réception et envoi de SMS |
| `READ_PHONE_STATE` / `CALL_PHONE` | Détection et journal d'appels |
| `READ_CONTACTS` | Recherche de contacts pour SMS |
| `POST_NOTIFICATIONS` | Affichage des alertes MoodSync |
| `BIND_NOTIFICATION_LISTENER_SERVICE` | Lecture des notifications tierces |

## 🛠 Stack technique

- **Kotlin** + **Jetpack Compose** (UI déclarative)
- **Room** (base de données locale SQLite)
- **Coroutines + Flow** (async)
- **ViewModel + StateFlow** (architecture)
- **Material 3** (design system)
- **GitHub Actions** (CI/CD → APK automatique)

## 📂 Architecture

```
com.moodsync.app/
├── data/
│   ├── model/          # MoodEntry, MoodNotification, CallEntry, etc.
│   └── repository/     # Room DB + DAOs + MoodSyncRepository
├── receiver/           # SmsReceiver, CallReceiver, BootReceiver
├── service/            # NotificationListenerService, CallHandlerService
├── ui/
│   ├── screens/        # Home, Notifications, Messages, Calls, Stats
│   ├── theme/          # Couleurs, typographie, thème dark
│   └── MoodSyncViewModel.kt
└── utils/              # NotificationHelper
```

## ⚙️ Premier lancement

1. Accordez toutes les permissions demandées
2. Allez dans **Paramètres Android > Accès aux notifications** et activez MoodSync
3. Commencez à logger votre humeur depuis l'écran principal

---
Made with 🌿 and Kotlin

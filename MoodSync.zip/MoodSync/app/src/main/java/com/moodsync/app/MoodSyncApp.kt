package com.moodsync.app

import android.app.Application
import com.moodsync.app.utils.NotificationHelper

class MoodSyncApp : Application() {
    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createNotificationChannels(this)
    }
}

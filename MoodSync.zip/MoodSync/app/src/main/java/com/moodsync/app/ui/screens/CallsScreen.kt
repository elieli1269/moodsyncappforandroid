package com.moodsync.app.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.moodsync.app.data.model.*
import com.moodsync.app.ui.MoodSyncViewModel
import com.moodsync.app.ui.UiState
import com.moodsync.app.ui.theme.MoodColors
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun CallsScreen(vm: MoodSyncViewModel, state: UiState) {
    val context = LocalContext.current
    var showDialer by remember { mutableStateOf(false) }
    var dialNumber by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MoodColors.Background)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Appels",
                style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Black),
                color = MoodColors.TextPrimary
            )
            FloatingActionButton(
                onClick = { showDialer = true },
                containerColor = MoodColors.Success,
                modifier = Modifier.size(44.dp)
            ) {
                Icon(Icons.Filled.Phone, contentDescription = "Appeler", tint = Color.Black)
            }
        }

        if (state.recentCalls.isEmpty()) {
            EmptyState(
                icon = "📞",
                title = "Aucun appel enregistré",
                subtitle = "Vos appels entrants et sortants apparaîtront ici"
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(state.recentCalls) { call ->
                    CallItem(
                        call = call,
                        onCallback = {
                            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:${call.number}"))
                            context.startActivity(intent)
                        }
                    )
                }
            }
        }
    }

    if (showDialer) {
        QuickDialerSheet(
            number = dialNumber,
            onNumberChange = { dialNumber = it },
            onCall = {
                if (dialNumber.isNotBlank()) {
                    val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$dialNumber"))
                    context.startActivity(intent)
                    showDialer = false
                }
            },
            onDismiss = { showDialer = false }
        )
    }
}

@Composable
private fun CallItem(call: CallEntry, onCallback: () -> Unit) {
    val category = try { NotifCategory.valueOf(call.type) } catch (e: Exception) { NotifCategory.CALL_INCOMING }
    val (icon, color, label) = when (category) {
        NotifCategory.CALL_INCOMING -> Triple("📞", MoodColors.Success, "Entrant")
        NotifCategory.CALL_MISSED -> Triple("📵", MoodColors.Error, "Manqué")
        NotifCategory.CALL_OUTGOING -> Triple("📤", MoodColors.Info, "Sortant")
        else -> Triple("📞", MoodColors.TextSecondary, "Appel")
    }

    val mood = try { MoodType.fromName(call.moodBefore) } catch (e: Exception) { MoodType.NEUTRAL }
    val moodColor = Color(mood.color)
    val fmt = SimpleDateFormat("dd MMM · HH:mm", Locale.FRANCE)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MoodColors.Surface, RoundedCornerShape(16.dp))
            .padding(14.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(icon, fontSize = 24.sp)
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(call.name.ifBlank { call.number }, style = MaterialTheme.typography.titleMedium, color = MoodColors.TextPrimary)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(label, style = MaterialTheme.typography.labelSmall, color = color)
                if (call.duration > 0) {
                    Text("·", color = MoodColors.TextMuted)
                    Text(formatDuration(call.duration), style = MaterialTheme.typography.labelSmall, color = MoodColors.TextSecondary)
                }
                Text("·", color = MoodColors.TextMuted)
                Text(fmt.format(Date(call.timestamp)), style = MaterialTheme.typography.labelSmall, color = MoodColors.TextMuted)
            }
            Row(
                modifier = Modifier
                    .background(moodColor.copy(alpha = 0.1f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(mood.emoji, fontSize = 11.sp)
                Text(mood.label, style = MaterialTheme.typography.labelSmall, color = moodColor)
            }
        }
        IconButton(onClick = onCallback) {
            Icon(Icons.Filled.Phone, contentDescription = "Rappeler", tint = MoodColors.Success)
        }
    }
}

private fun formatDuration(seconds: Long): String {
    val m = seconds / 60
    val s = seconds % 60
    return if (m > 0) "${m}min ${s}s" else "${s}s"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun QuickDialerSheet(
    number: String,
    onNumberChange: (String) -> Unit,
    onCall: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MoodColors.Surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Composer", style = MaterialTheme.typography.headlineMedium, color = MoodColors.TextPrimary)

            OutlinedTextField(
                value = number,
                onValueChange = onNumberChange,
                label = { Text("Numéro", color = MoodColors.TextSecondary) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MoodColors.Success,
                    unfocusedBorderColor = MoodColors.TextMuted,
                    focusedTextColor = MoodColors.TextPrimary,
                    unfocusedTextColor = MoodColors.TextPrimary
                )
            )

            // Numpad
            val digits = listOf("1","2","3","4","5","6","7","8","9","*","0","#")
            digits.chunked(3).forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    row.forEach { digit ->
                        OutlinedButton(
                            onClick = { onNumberChange(number + digit) },
                            modifier = Modifier.weight(1f),
                            shape = CircleShape,
                            border = BorderStroke(1.dp, MoodColors.TextMuted)
                        ) {
                            Text(digit, style = MaterialTheme.typography.headlineMedium, color = MoodColors.TextPrimary)
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                OutlinedButton(
                    onClick = { if (number.isNotEmpty()) onNumberChange(number.dropLast(1)) },
                    modifier = Modifier.weight(1f),
                    border = BorderStroke(1.dp, MoodColors.TextMuted)
                ) {
                    Icon(Icons.Filled.Backspace, contentDescription = null, tint = MoodColors.TextSecondary)
                }
                Button(
                    onClick = onCall,
                    modifier = Modifier.weight(2f),
                    colors = ButtonDefaults.buttonColors(containerColor = MoodColors.Success),
                    enabled = number.isNotBlank()
                ) {
                    Icon(Icons.Filled.Phone, contentDescription = null, tint = Color.Black)
                    Spacer(Modifier.width(8.dp))
                    Text("Appeler", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

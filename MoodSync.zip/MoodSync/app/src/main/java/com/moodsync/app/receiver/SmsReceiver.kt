package com.moodsync.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import com.moodsync.app.data.model.MoodNotification
import com.moodsync.app.data.model.MoodType
import com.moodsync.app.data.model.NotifCategory
import com.moodsync.app.data.repository.MoodSyncRepository
import com.moodsync.app.utils.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isNullOrEmpty()) return

        val sender = messages[0].originatingAddress ?: "Inconnu"
        val fullBody = messages.joinToString("") { it.messageBody }

        CoroutineScope(Dispatchers.IO).launch {
            val repo = MoodSyncRepository(context)
            val currentMood = repo.getLatestMood()?.moodType ?: MoodType.NEUTRAL

            repo.saveNotification(
                MoodNotification(
                    category = NotifCategory.SMS.name,
                    sender = sender,
                    senderNumber = sender,
                    content = fullBody,
                    appPackage = "com.android.mms",
                    appName = "SMS",
                    moodSnapshot = currentMood.name
                )
            )

            // Show heads-up notification
            NotificationHelper.showSmsNotification(context, sender, fullBody)
        }
    }
}

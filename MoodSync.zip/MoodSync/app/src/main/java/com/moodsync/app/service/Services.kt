package com.moodsync.app.service

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.moodsync.app.utils.NotificationHelper

/**
 * Foreground service for handling active call state tracking
 */
class CallHandlerService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notif = NotificationCompat.Builder(this, NotificationHelper.CHANNEL_SERVICE)
            .setContentTitle("MoodSync")
            .setContentText("Suivi d'appel actif")
            .setSmallIcon(android.R.drawable.ic_menu_call)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
        startForeground(1001, notif)
        return START_STICKY
    }
}

/**
 * Background sync service for mood reminders
 */
class MoodSyncService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notif = NotificationCompat.Builder(this, NotificationHelper.CHANNEL_SERVICE)
            .setContentTitle("MoodSync")
            .setContentText("Synchronisation en cours...")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
        startForeground(1002, notif)

        // Schedule mood reminder
        NotificationHelper.showMoodReminder(this)
        stopSelf()
        return START_NOT_STICKY
    }
}

package com.moodsync.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import com.moodsync.app.data.model.CallEntry
import com.moodsync.app.data.model.MoodNotification
import com.moodsync.app.data.model.MoodType
import com.moodsync.app.data.model.NotifCategory
import com.moodsync.app.data.repository.MoodSyncRepository
import com.moodsync.app.utils.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CallReceiver : BroadcastReceiver() {

    companion object {
        private var lastState = TelephonyManager.CALL_STATE_IDLE
        private var callStartTime = 0L
        private var incomingNumber = ""
    }

    override fun onReceive(context: Context, intent: Intent) {
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: ""

        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                incomingNumber = number
                lastState = TelephonyManager.CALL_STATE_RINGING
                handleIncomingCall(context, number)
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                callStartTime = System.currentTimeMillis()
                if (lastState == TelephonyManager.CALL_STATE_RINGING) {
                    lastState = TelephonyManager.CALL_STATE_OFFHOOK
                }
            }
            TelephonyManager.EXTRA_STATE_IDLE -> {
                when (lastState) {
                    TelephonyManager.CALL_STATE_RINGING -> {
                        // Missed call
                        handleMissedCall(context, incomingNumber)
                    }
                    TelephonyManager.CALL_STATE_OFFHOOK -> {
                        // Call ended
                        val duration = if (callStartTime > 0)
                            (System.currentTimeMillis() - callStartTime) / 1000 else 0
                        handleCallEnded(context, incomingNumber, duration)
                    }
                }
                lastState = TelephonyManager.CALL_STATE_IDLE
                callStartTime = 0L
            }
        }
    }

    private fun handleIncomingCall(context: Context, number: String) {
        CoroutineScope(Dispatchers.IO).launch {
            val repo = MoodSyncRepository(context)
            val mood = repo.getLatestMood()?.moodType ?: MoodType.NEUTRAL
            repo.saveNotification(
                MoodNotification(
                    category = NotifCategory.CALL_INCOMING.name,
                    sender = number,
                    senderNumber = number,
                    content = "Appel entrant",
                    appName = "Téléphone",
                    moodSnapshot = mood.name
                )
            )
            NotificationHelper.showCallNotification(context, number, "Appel entrant")
        }
    }

    private fun handleMissedCall(context: Context, number: String) {
        CoroutineScope(Dispatchers.IO).launch {
            val repo = MoodSyncRepository(context)
            val mood = repo.getLatestMood()?.moodType ?: MoodType.NEUTRAL
            repo.logCall(
                CallEntry(
                    name = number,
                    number = number,
                    type = NotifCategory.CALL_MISSED.name,
                    moodBefore = mood.name
                )
            )
            repo.saveNotification(
                MoodNotification(
                    category = NotifCategory.CALL_MISSED.name,
                    sender = number,
                    senderNumber = number,
                    content = "Appel manqué",
                    appName = "Téléphone",
                    moodSnapshot = mood.name
                )
            )
            NotificationHelper.showCallNotification(context, number, "Appel manqué")
        }
    }

    private fun handleCallEnded(context: Context, number: String, duration: Long) {
        CoroutineScope(Dispatchers.IO).launch {
            val repo = MoodSyncRepository(context)
            val mood = repo.getLatestMood()?.moodType ?: MoodType.NEUTRAL
            repo.logCall(
                CallEntry(
                    name = number,
                    number = number,
                    type = NotifCategory.CALL_INCOMING.name,
                    duration = duration,
                    moodBefore = mood.name
                )
            )
        }
    }
}

package com.moodsync.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.moodsync.app.ui.MoodSyncViewModel
import com.moodsync.app.ui.theme.MoodColors

sealed class NavRoute(val route: String, val label: String, val icon: ImageVector) {
    object Home : NavRoute("home", "Humeur", Icons.Filled.SelfImprovement)
    object Notifications : NavRoute("notifications", "Notifs", Icons.Filled.Notifications)
    object Messages : NavRoute("messages", "Messages", Icons.Filled.Message)
    object Calls : NavRoute("calls", "Appels", Icons.Filled.Phone)
    object Stats : NavRoute("stats", "Stats", Icons.Filled.BarChart)
}

val navItems = listOf(
    NavRoute.Home,
    NavRoute.Notifications,
    NavRoute.Messages,
    NavRoute.Calls,
    NavRoute.Stats
)

@Composable
fun MainScreen(
    onRequestNotifListenerAccess: () -> Unit,
    notifListenerEnabled: Boolean
) {
    val vm: MoodSyncViewModel = viewModel()
    val state by vm.state.collectAsState()
    val navController = rememberNavController()

    Scaffold(
        containerColor = MoodColors.Background,
        bottomBar = {
            NavigationBar(
                containerColor = MoodColors.Surface,
                contentColor = MoodColors.TextSecondary,
                tonalElevation = 0.dp
            ) {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDest = navBackStackEntry?.destination

                navItems.forEach { screen ->
                    val selected = currentDest?.hierarchy?.any { it.route == screen.route } == true
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (screen is NavRoute.Notifications && state.unreadCount > 0) {
                                        Badge { Text("${state.unreadCount}") }
                                    }
                                }
                            ) {
                                Icon(screen.icon, contentDescription = screen.label)
                            }
                        },
                        label = { Text(screen.label, style = MaterialTheme.typography.labelSmall) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MoodColors.Primary,
                            selectedTextColor = MoodColors.Primary,
                            indicatorColor = MoodColors.Primary.copy(alpha = 0.15f),
                            unselectedIconColor = MoodColors.TextMuted,
                            unselectedTextColor = MoodColors.TextMuted
                        )
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = NavRoute.Home.route,
            modifier = Modifier.padding(padding),
            enterTransition = { fadeIn() + slideInHorizontally() },
            exitTransition = { fadeOut() + slideOutHorizontally() }
        ) {
            composable(NavRoute.Home.route) {
                HomeScreen(vm = vm, state = state)
            }
            composable(NavRoute.Notifications.route) {
                NotificationsScreen(
                    vm = vm,
                    state = state,
                    notifListenerEnabled = notifListenerEnabled,
                    onRequestAccess = onRequestNotifListenerAccess
                )
            }
            composable(NavRoute.Messages.route) {
                MessagesScreen(vm = vm, state = state)
            }
            composable(NavRoute.Calls.route) {
                CallsScreen(vm = vm, state = state)
            }
            composable(NavRoute.Stats.route) {
                StatsScreen(vm = vm, state = state)
            }
        }
    }
}

package com.moodsync.app.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.moodsync.app.MainActivity
import com.moodsync.app.R

object NotificationHelper {

    const val CHANNEL_SMS = "moodsync_sms"
    const val CHANNEL_CALLS = "moodsync_calls"
    const val CHANNEL_MOOD = "moodsync_mood"
    const val CHANNEL_SERVICE = "moodsync_service"

    fun createNotificationChannels(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_SMS, "SMS", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Notifications SMS reçus"
                enableVibration(true)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_CALLS, "Appels", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Appels entrants et manqués"
                enableVibration(true)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_MOOD, "Humeur", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Rappels de journalisation d'humeur"
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_SERVICE, "Service", NotificationManager.IMPORTANCE_MIN).apply {
                description = "Service en arrière-plan"
            }
        )
    }

    fun showSmsNotification(context: Context, sender: String, content: String) {
        val intent = Intent(context, MainActivity::class.java).apply {
            action = "com.moodsync.OPEN_NOTIFICATION"
            putExtra("tab", "notifications")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val notif = NotificationCompat.Builder(context, CHANNEL_SMS)
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle("SMS de $sender")
            .setContentText(content)
            .setStyle(NotificationCompat.BigTextStyle().bigText(content))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(System.currentTimeMillis().toInt(), notif)
    }

    fun showCallNotification(context: Context, number: String, type: String) {
        val intent = Intent(context, MainActivity::class.java).apply {
            action = "com.moodsync.OPEN_NOTIFICATION"
            putExtra("tab", "calls")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val notif = NotificationCompat.Builder(context, CHANNEL_CALLS)
            .setSmallIcon(android.R.drawable.ic_menu_call)
            .setContentTitle(type)
            .setContentText(number)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(System.currentTimeMillis().toInt(), notif)
    }

    fun showMoodReminder(context: Context) {
        val intent = Intent(context, MainActivity::class.java).apply {
            action = "com.moodsync.LOG_MOOD"
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val notif = NotificationCompat.Builder(context, CHANNEL_MOOD)
            .setSmallIcon(android.R.drawable.star_big_on)
            .setContentTitle("Comment vous sentez-vous ? 🌿")
            .setContentText("Prenez un moment pour noter votre humeur")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(9999, notif)
    }
}

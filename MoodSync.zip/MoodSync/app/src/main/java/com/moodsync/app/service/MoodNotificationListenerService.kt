package com.moodsync.app.service

import android.app.Notification
import android.content.pm.PackageManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.moodsync.app.data.model.MoodNotification
import com.moodsync.app.data.model.MoodType
import com.moodsync.app.data.model.NotifCategory
import com.moodsync.app.data.repository.MoodSyncRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class MoodNotificationListenerService : NotificationListenerService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var repository: MoodSyncRepository

    // Apps à exclure (system noise)
    private val excludedPackages = setOf(
        "com.android.systemui",
        "com.google.android.gms",
        "com.moodsync.app",
        "com.moodsync.app.debug"
    )

    override fun onCreate() {
        super.onCreate()
        repository = MoodSyncRepository(this)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName in excludedPackages) return
        if (sbn.isOngoing) return // skip persistent notifs

        val extras = sbn.notification.extras
        val title = extras.getString(Notification.EXTRA_TITLE) ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val appName = getAppName(sbn.packageName)

        // Skip empty notifications
        if (title.isBlank() && text.isBlank()) return

        scope.launch {
            val currentMood = repository.getLatestMood()?.moodType ?: MoodType.NEUTRAL
            repository.saveNotification(
                MoodNotification(
                    category = NotifCategory.APP_NOTIF.name,
                    sender = title,
                    content = text,
                    appPackage = sbn.packageName,
                    appName = appName,
                    moodSnapshot = currentMood.name
                )
            )
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        // Could track dismissals for mood correlation
    }

    private fun getAppName(packageName: String): String {
        return try {
            val pm = packageManager
            val info = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(info).toString()
        } catch (e: PackageManager.NameNotFoundException) {
            packageName
        }
    }
}

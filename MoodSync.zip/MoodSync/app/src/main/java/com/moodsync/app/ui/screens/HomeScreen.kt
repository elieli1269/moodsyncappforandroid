package com.moodsync.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.moodsync.app.data.model.*
import com.moodsync.app.ui.MoodSyncViewModel
import com.moodsync.app.ui.UiState
import com.moodsync.app.ui.theme.MoodColors
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HomeScreen(vm: MoodSyncViewModel, state: UiState) {
    var showMoodPicker by remember { mutableStateOf(false) }
    var showNoteDialog by remember { mutableStateOf(false) }
    var selectedMood by remember { mutableStateOf<MoodType?>(null) }
    var moodNote by remember { mutableStateOf("") }
    var energyLevel by remember { mutableStateOf(5) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MoodColors.Background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { HeaderSection(state) }
        item { CurrentMoodCard(state.currentMood) { showMoodPicker = true } }
        item { QuickMoodRow { mood -> vm.logMood(mood) } }
        if (state.recentMoods.isNotEmpty()) {
            item {
                Text(
                    "Historique récent",
                    style = MaterialTheme.typography.titleMedium,
                    color = MoodColors.TextSecondary,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            items(state.recentMoods.take(7)) { entry ->
                MoodHistoryItem(entry)
            }
        }
    }

    // Full mood picker sheet
    if (showMoodPicker) {
        MoodPickerSheet(
            onDismiss = { showMoodPicker = false },
            onMoodSelected = { mood ->
                selectedMood = mood
                showMoodPicker = false
                showNoteDialog = true
            }
        )
    }

    // Note dialog
    if (showNoteDialog && selectedMood != null) {
        MoodNoteDialog(
            mood = selectedMood!!,
            note = moodNote,
            energy = energyLevel,
            onNoteChange = { moodNote = it },
            onEnergyChange = { energyLevel = it },
            onConfirm = {
                vm.logMood(selectedMood!!, moodNote, energyLevel)
                moodNote = ""
                energyLevel = 5
                showNoteDialog = false
            },
            onDismiss = { showNoteDialog = false }
        )
    }
}

@Composable
private fun HeaderSection(state: UiState) {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val greeting = when {
        hour < 6 -> "Bonne nuit"
        hour < 12 -> "Bonjour"
        hour < 18 -> "Bon après-midi"
        else -> "Bonsoir"
    }
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(greeting, style = MaterialTheme.typography.bodyMedium, color = MoodColors.TextSecondary)
            Text(
                "MoodSync",
                style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Black),
                color = MoodColors.TextPrimary
            )
        }
        // Streak badge
        val stats = state.recentMoods.size
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MoodColors.Primary.copy(alpha = 0.15f)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text("🔥", fontSize = 16.sp)
                Text(
                    "$stats logs",
                    style = MaterialTheme.typography.labelLarge,
                    color = MoodColors.Primary
                )
            }
        }
    }
}

@Composable
private fun CurrentMoodCard(mood: MoodType, onClick: () -> Unit) {
    val moodColor = Color(mood.color)
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        border = BorderStroke(1.dp, moodColor.copy(alpha = 0.3f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            moodColor.copy(alpha = 0.15f),
                            MoodColors.Surface
                        ),
                        start = Offset.Zero,
                        end = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
                    )
                )
                .padding(24.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Humeur actuelle",
                    style = MaterialTheme.typography.labelLarge,
                    color = MoodColors.TextSecondary
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        mood.emoji,
                        fontSize = (48 * scale).sp
                    )
                    Column {
                        Text(
                            mood.label,
                            style = MaterialTheme.typography.headlineMedium,
                            color = moodColor,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Appuyer pour modifier",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MoodColors.TextMuted
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickMoodRow(onMoodTap: (MoodType) -> Unit) {
    Text(
        "Saisie rapide",
        style = MaterialTheme.typography.labelLarge,
        color = MoodColors.TextSecondary
    )
    Spacer(Modifier.height(8.dp))
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(MoodType.values()) { mood ->
            MoodChip(mood = mood, onClick = { onMoodTap(mood) })
        }
    }
}

@Composable
private fun MoodChip(mood: MoodType, onClick: () -> Unit) {
    val color = Color(mood.color)
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = color.copy(alpha = 0.12f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(mood.emoji, fontSize = 24.sp)
            Text(mood.label, style = MaterialTheme.typography.labelSmall, color = color)
        }
    }
}

@Composable
private fun MoodHistoryItem(entry: MoodEntry) {
    val mood = entry.moodType
    val color = Color(mood.color)
    val fmt = SimpleDateFormat("dd MMM · HH:mm", Locale.FRANCE)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MoodColors.Surface, RoundedCornerShape(12.dp))
            .padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(mood.emoji, fontSize = 28.sp)
        Column(modifier = Modifier.weight(1f)) {
            Text(mood.label, style = MaterialTheme.typography.titleMedium, color = color)
            if (entry.note.isNotBlank()) {
                Text(entry.note, style = MaterialTheme.typography.bodyMedium, color = MoodColors.TextSecondary, maxLines = 1)
            }
            Text(
                fmt.format(Date(entry.timestamp)),
                style = MaterialTheme.typography.labelSmall,
                color = MoodColors.TextMuted
            )
        }
        // Energy indicator
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("⚡", fontSize = 14.sp)
            Text("${entry.energy}/10", style = MaterialTheme.typography.labelSmall, color = MoodColors.TextMuted)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MoodPickerSheet(onDismiss: () -> Unit, onMoodSelected: (MoodType) -> Unit) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MoodColors.Surface,
        contentColor = MoodColors.TextPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                "Comment vous sentez-vous ?",
                style = MaterialTheme.typography.headlineMedium,
                color = MoodColors.TextPrimary
            )
            MoodType.values().chunked(2).forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    row.forEach { mood ->
                        val color = Color(mood.color)
                        Card(
                            onClick = { onMoodSelected(mood) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.1f)),
                            border = BorderStroke(1.dp, color.copy(alpha = 0.25f))
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(mood.emoji, fontSize = 28.sp)
                                Text(mood.label, style = MaterialTheme.typography.titleMedium, color = color)
                            }
                        }
                    }
                    if (row.size == 1) Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun MoodNoteDialog(
    mood: MoodType,
    note: String,
    energy: Int,
    onNoteChange: (String) -> Unit,
    onEnergyChange: (Int) -> Unit,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    val color = Color(mood.color)
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MoodColors.Surface,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(mood.emoji, fontSize = 28.sp)
                Text(mood.label, color = color, style = MaterialTheme.typography.headlineMedium)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                OutlinedTextField(
                    value = note,
                    onValueChange = onNoteChange,
                    label = { Text("Note (optionnelle)", color = MoodColors.TextSecondary) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = color,
                        unfocusedBorderColor = MoodColors.TextMuted,
                        focusedTextColor = MoodColors.TextPrimary,
                        unfocusedTextColor = MoodColors.TextPrimary
                    ),
                    maxLines = 3
                )
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Énergie", style = MaterialTheme.typography.labelLarge, color = MoodColors.TextSecondary)
                        Text("$energy/10", style = MaterialTheme.typography.labelLarge, color = color)
                    }
                    Slider(
                        value = energy.toFloat(),
                        onValueChange = { onEnergyChange(it.toInt()) },
                        valueRange = 1f..10f,
                        steps = 8,
                        colors = SliderDefaults.colors(
                            thumbColor = color,
                            activeTrackColor = color,
                            inactiveTrackColor = color.copy(alpha = 0.2f)
                        )
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = color)
            ) {
                Text("Enregistrer", color = Color.Black)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Annuler", color = MoodColors.TextSecondary)
            }
        }
    )
}

package com.moodsync.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

// ─── MOOD ───────────────────────────────────────────────────────────────────

enum class MoodType(val emoji: String, val label: String, val color: Long) {
    ELATED("🤩", "Euphorique", 0xFFFFD700),
    HAPPY("😊", "Heureux", 0xFF4CAF50),
    CALM("😌", "Calme", 0xFF64B5F6),
    NEUTRAL("😐", "Neutre", 0xFF9E9E9E),
    TIRED("😴", "Fatigué", 0xFF8D6E63),
    STRESSED("😤", "Stressé", 0xFFFF9800),
    SAD("😢", "Triste", 0xFF5C6BC0),
    ANGRY("😠", "En colère", 0xFFF44336);

    companion object {
        fun fromName(name: String) = values().find { it.name == name } ?: NEUTRAL
    }
}

@Entity(tableName = "moods")
data class MoodEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String = MoodType.NEUTRAL.name,
    val note: String = "",
    val energy: Int = 5, // 1-10
    val timestamp: Long = System.currentTimeMillis(),
    val tags: String = "" // comma-separated
) {
    val moodType: MoodType get() = MoodType.fromName(type)
}

// ─── NOTIFICATION ────────────────────────────────────────────────────────────

enum class NotifCategory { SMS, CALL_INCOMING, CALL_MISSED, CALL_OUTGOING, APP_NOTIF }

@Entity(tableName = "notifications")
data class MoodNotification(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String = NotifCategory.APP_NOTIF.name,
    val sender: String = "",
    val senderNumber: String = "",
    val content: String = "",
    val appPackage: String = "",
    val appName: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val moodSnapshot: String = MoodType.NEUTRAL.name // mood at time of reception
)

// ─── MESSAGE ─────────────────────────────────────────────────────────────────

@Entity(tableName = "messages")
data class QuickMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val recipient: String = "",
    val recipientNumber: String = "",
    val content: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val sent: Boolean = false,
    val moodAtSend: String = MoodType.NEUTRAL.name
)

// ─── CONTACT ─────────────────────────────────────────────────────────────────

data class Contact(
    val id: String,
    val name: String,
    val number: String,
    val photoUri: String? = null
)

// ─── QUICK REPLY TEMPLATE ────────────────────────────────────────────────────

@Entity(tableName = "quick_replies")
data class QuickReply(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val label: String = "",
    val content: String = "",
    val moodTag: String = "" // optional link to a mood
)

// ─── CALL LOG ────────────────────────────────────────────────────────────────

@Entity(tableName = "call_log")
data class CallEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String = "",
    val number: String = "",
    val type: String = NotifCategory.CALL_INCOMING.name,
    val duration: Long = 0L, // seconds
    val timestamp: Long = System.currentTimeMillis(),
    val moodBefore: String = MoodType.NEUTRAL.name,
    val moodAfter: String = ""
)

// ─── STATS ───────────────────────────────────────────────────────────────────

data class MoodStats(
    val mostFrequent: MoodType,
    val averageEnergy: Float,
    val totalEntries: Int,
    val streak: Int, // days in a row
    val weeklyData: List<Pair<String, MoodType>> // day -> mood
)

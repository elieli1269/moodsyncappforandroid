package com.moodsync.app.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// ─── PALETTE ─────────────────────────────────────────────────────────────────

object MoodColors {
    // Dark theme base
    val Background = Color(0xFF0D0F14)
    val Surface = Color(0xFF161B22)
    val SurfaceVariant = Color(0xFF1E2530)
    val Overlay = Color(0xFF242D38)

    // Accent — teal/cyan gradient
    val Primary = Color(0xFF00E5CC)
    val PrimaryDim = Color(0xFF00B3A0)
    val Secondary = Color(0xFF7C6FFF)
    val Tertiary = Color(0xFFFF6B9D)

    // Text
    val TextPrimary = Color(0xFFF0F4F8)
    val TextSecondary = Color(0xFF8896A4)
    val TextMuted = Color(0xFF4A5568)

    // Mood palette
    val MoodElated = Color(0xFFFFD700)
    val MoodHappy = Color(0xFF4CAF50)
    val MoodCalm = Color(0xFF64B5F6)
    val MoodNeutral = Color(0xFF9E9E9E)
    val MoodTired = Color(0xFF8D6E63)
    val MoodStressed = Color(0xFFFF9800)
    val MoodSad = Color(0xFF5C6BC0)
    val MoodAngry = Color(0xFFF44336)

    // Status
    val Success = Color(0xFF00C896)
    val Warning = Color(0xFFFFB020)
    val Error = Color(0xFFFF4757)
    val Info = Color(0xFF3498FF)
}

private val darkColorScheme = darkColorScheme(
    primary = MoodColors.Primary,
    onPrimary = Color(0xFF001A18),
    primaryContainer = Color(0xFF00352F),
    onPrimaryContainer = MoodColors.Primary,
    secondary = MoodColors.Secondary,
    onSecondary = Color(0xFF0F0A2E),
    tertiary = MoodColors.Tertiary,
    background = MoodColors.Background,
    onBackground = MoodColors.TextPrimary,
    surface = MoodColors.Surface,
    onSurface = MoodColors.TextPrimary,
    surfaceVariant = MoodColors.SurfaceVariant,
    onSurfaceVariant = MoodColors.TextSecondary,
    outline = MoodColors.TextMuted,
    error = MoodColors.Error
)

val MoodTypography = Typography(
    displayLarge = TextStyle(
        fontWeight = FontWeight.Black,
        fontSize = 48.sp,
        lineHeight = 52.sp,
        letterSpacing = (-2).sp
    ),
    headlineLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 30.sp,
        lineHeight = 36.sp,
        letterSpacing = (-0.5).sp
    ),
    headlineMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 24.sp,
        lineHeight = 30.sp
    ),
    titleLarge = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp,
        lineHeight = 24.sp
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 16.sp,
        lineHeight = 22.sp
    ),
    bodyLarge = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp
    ),
    bodyMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    labelLarge = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        letterSpacing = 0.5.sp
    ),
    labelSmall = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        letterSpacing = 0.5.sp
    )
)

@Composable
fun MoodSyncTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme,
        typography = MoodTypography,
        content = content
    )
}

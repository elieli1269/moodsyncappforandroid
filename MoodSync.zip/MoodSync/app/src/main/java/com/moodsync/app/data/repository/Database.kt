package com.moodsync.app.data.repository

import android.content.Context
import androidx.room.*
import com.moodsync.app.data.model.*
import kotlinx.coroutines.flow.Flow

// ─── DAOs ─────────────────────────────────────────────────────────────────────

@Dao
interface MoodDao {
    @Query("SELECT * FROM moods ORDER BY timestamp DESC")
    fun getAllMoods(): Flow<List<MoodEntry>>

    @Query("SELECT * FROM moods ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLatestMood(): MoodEntry?

    @Query("SELECT * FROM moods WHERE timestamp >= :from AND timestamp <= :to ORDER BY timestamp DESC")
    fun getMoodsInRange(from: Long, to: Long): Flow<List<MoodEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMood(mood: MoodEntry): Long

    @Delete
    suspend fun deleteMood(mood: MoodEntry)

    @Query("SELECT COUNT(*) FROM moods")
    suspend fun getTotalCount(): Int
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC LIMIT 100")
    fun getAllNotifications(): Flow<List<MoodNotification>>

    @Query("SELECT * FROM notifications WHERE isRead = 0 ORDER BY timestamp DESC")
    fun getUnreadNotifications(): Flow<List<MoodNotification>>

    @Query("SELECT COUNT(*) FROM notifications WHERE isRead = 0")
    fun getUnreadCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notif: MoodNotification): Long

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: Long)

    @Query("UPDATE notifications SET isRead = 1")
    suspend fun markAllAsRead()

    @Query("DELETE FROM notifications WHERE timestamp < :before")
    suspend fun deleteOlderThan(before: Long)
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages ORDER BY timestamp DESC LIMIT 50")
    fun getRecentMessages(): Flow<List<QuickMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(msg: QuickMessage): Long
}

@Dao
interface QuickReplyDao {
    @Query("SELECT * FROM quick_replies ORDER BY id ASC")
    fun getAll(): Flow<List<QuickReply>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(reply: QuickReply): Long

    @Delete
    suspend fun delete(reply: QuickReply)

    @Update
    suspend fun update(reply: QuickReply)
}

@Dao
interface CallDao {
    @Query("SELECT * FROM call_log ORDER BY timestamp DESC LIMIT 50")
    fun getRecentCalls(): Flow<List<CallEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(call: CallEntry): Long

    @Query("UPDATE call_log SET moodAfter = :mood WHERE id = :id")
    suspend fun updateMoodAfter(id: Long, mood: String)
}

// ─── DATABASE ─────────────────────────────────────────────────────────────────

@Database(
    entities = [MoodEntry::class, MoodNotification::class, QuickMessage::class, QuickReply::class, CallEntry::class],
    version = 1,
    exportSchema = false
)
abstract class MoodSyncDatabase : RoomDatabase() {
    abstract fun moodDao(): MoodDao
    abstract fun notificationDao(): NotificationDao
    abstract fun messageDao(): MessageDao
    abstract fun quickReplyDao(): QuickReplyDao
    abstract fun callDao(): CallDao

    companion object {
        @Volatile private var INSTANCE: MoodSyncDatabase? = null

        fun getInstance(context: Context): MoodSyncDatabase =
            INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    MoodSyncDatabase::class.java,
                    "moodsync.db"
                ).fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
    }
}

package com.moodsync.app.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.moodsync.app.data.model.*
import com.moodsync.app.ui.MoodSyncViewModel
import com.moodsync.app.ui.UiState
import com.moodsync.app.ui.theme.MoodColors
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun NotificationsScreen(
    vm: MoodSyncViewModel,
    state: UiState,
    notifListenerEnabled: Boolean,
    onRequestAccess: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MoodColors.Background)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Notifications",
                style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Black),
                color = MoodColors.TextPrimary
            )
            if (state.unreadCount > 0) {
                TextButton(onClick = { vm.markAllRead() }) {
                    Text("Tout lire", color = MoodColors.Primary)
                }
            }
        }

        // Listener permission banner
        if (!notifListenerEnabled) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MoodColors.Warning.copy(alpha = 0.12f)),
                border = BorderStroke(1.dp, MoodColors.Warning.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Warning, contentDescription = null, tint = MoodColors.Warning)
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Accès aux notifications requis",
                            style = MaterialTheme.typography.titleMedium,
                            color = MoodColors.Warning
                        )
                        Text(
                            "Activez l'accès pour que MoodSync puisse lire vos notifications.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MoodColors.TextSecondary
                        )
                    }
                    Button(
                        onClick = onRequestAccess,
                        colors = ButtonDefaults.buttonColors(containerColor = MoodColors.Warning)
                    ) {
                        Text("Activer", color = Color.Black)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        if (state.notifications.isEmpty()) {
            EmptyState(
                icon = "🔔",
                title = "Aucune notification",
                subtitle = "Vos SMS, appels et notifications apparaîtront ici"
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(state.notifications, key = { it.id }) { notif ->
                    NotificationItem(
                        notif = notif,
                        onRead = { vm.markNotifRead(notif.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun NotificationItem(notif: MoodNotification, onRead: () -> Unit) {
    val category = try { NotifCategory.valueOf(notif.category) } catch (e: Exception) { NotifCategory.APP_NOTIF }
    val (icon, tint) = when (category) {
        NotifCategory.SMS -> Pair("💬", MoodColors.Info)
        NotifCategory.CALL_INCOMING -> Pair("📞", MoodColors.Success)
        NotifCategory.CALL_MISSED -> Pair("📵", MoodColors.Error)
        NotifCategory.CALL_OUTGOING -> Pair("📤", MoodColors.TextSecondary)
        NotifCategory.APP_NOTIF -> Pair("🔔", MoodColors.Secondary)
    }

    val mood = try { MoodType.fromName(notif.moodSnapshot) } catch (e: Exception) { MoodType.NEUTRAL }
    val moodColor = Color(mood.color)
    val fmt = SimpleDateFormat("HH:mm · dd MMM", Locale.FRANCE)

    Card(
        onClick = onRead,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (!notif.isRead) MoodColors.SurfaceVariant else MoodColors.Surface
        ),
        border = if (!notif.isRead) BorderStroke(1.dp, tint.copy(alpha = 0.3f)) else null
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            // App/type icon
            Text(icon, fontSize = 24.sp, modifier = Modifier.padding(top = 2.dp))

            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        if (notif.appName.isNotBlank()) notif.appName else notif.category,
                        style = MaterialTheme.typography.labelLarge,
                        color = tint
                    )
                    Text(
                        fmt.format(Date(notif.timestamp)),
                        style = MaterialTheme.typography.labelSmall,
                        color = MoodColors.TextMuted
                    )
                }
                if (notif.sender.isNotBlank()) {
                    Text(
                        notif.sender,
                        style = MaterialTheme.typography.titleMedium,
                        color = MoodColors.TextPrimary
                    )
                }
                if (notif.content.isNotBlank()) {
                    Text(
                        notif.content,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MoodColors.TextSecondary,
                        maxLines = 2
                    )
                }
                // Mood context tag
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier
                        .background(moodColor.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(mood.emoji, fontSize = 12.sp)
                    Text(
                        "Humeur: ${mood.label}",
                        style = MaterialTheme.typography.labelSmall,
                        color = moodColor
                    )
                }
            }
        }
    }
}

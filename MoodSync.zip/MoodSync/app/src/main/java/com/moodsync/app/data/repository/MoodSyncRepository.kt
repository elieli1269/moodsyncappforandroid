package com.moodsync.app.data.repository

import android.content.Context
import android.database.Cursor
import android.provider.ContactsContract
import android.telephony.SmsManager
import com.moodsync.app.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class MoodSyncRepository(context: Context) {

    private val db = MoodSyncDatabase.getInstance(context)
    private val ctx = context.applicationContext

    // ─── MOOD ────────────────────────────────────────────────────────────────

    fun getAllMoods(): Flow<List<MoodEntry>> = db.moodDao().getAllMoods()

    suspend fun getLatestMood(): MoodEntry? = db.moodDao().getLatestMood()

    suspend fun logMood(type: MoodType, note: String = "", energy: Int = 5, tags: List<String> = emptyList()): Long =
        db.moodDao().insertMood(
            MoodEntry(
                type = type.name,
                note = note,
                energy = energy,
                tags = tags.joinToString(",")
            )
        )

    suspend fun deleteMood(mood: MoodEntry) = db.moodDao().deleteMood(mood)

    fun getMoodsInRange(from: Long, to: Long) = db.moodDao().getMoodsInRange(from, to)

    // ─── NOTIFICATIONS ───────────────────────────────────────────────────────

    fun getAllNotifications(): Flow<List<MoodNotification>> = db.notificationDao().getAllNotifications()

    fun getUnreadNotifications(): Flow<List<MoodNotification>> = db.notificationDao().getUnreadNotifications()

    fun getUnreadCount(): Flow<Int> = db.notificationDao().getUnreadCount()

    suspend fun saveNotification(notif: MoodNotification): Long =
        db.notificationDao().insertNotification(notif)

    suspend fun markNotifAsRead(id: Long) = db.notificationDao().markAsRead(id)

    suspend fun markAllNotifsAsRead() = db.notificationDao().markAllAsRead()

    // ─── MESSAGES ────────────────────────────────────────────────────────────

    fun getRecentMessages(): Flow<List<QuickMessage>> = db.messageDao().getRecentMessages()

    suspend fun sendSms(recipient: String, number: String, content: String, currentMood: MoodType) {
        withContext(Dispatchers.IO) {
            try {
                val smsManager = ctx.getSystemService(SmsManager::class.java)
                    ?: SmsManager.getDefault()
                val parts = smsManager.divideMessage(content)
                if (parts.size == 1) {
                    smsManager.sendTextMessage(number, null, content, null, null)
                } else {
                    smsManager.sendMultipartTextMessage(number, null, parts, null, null)
                }
                db.messageDao().insertMessage(
                    QuickMessage(
                        recipient = recipient,
                        recipientNumber = number,
                        content = content,
                        sent = true,
                        moodAtSend = currentMood.name
                    )
                )
            } catch (e: Exception) {
                db.messageDao().insertMessage(
                    QuickMessage(
                        recipient = recipient,
                        recipientNumber = number,
                        content = content,
                        sent = false,
                        moodAtSend = currentMood.name
                    )
                )
            }
        }
    }

    // ─── QUICK REPLIES ───────────────────────────────────────────────────────

    fun getQuickReplies(): Flow<List<QuickReply>> = db.quickReplyDao().getAll()

    suspend fun saveQuickReply(reply: QuickReply) = db.quickReplyDao().insert(reply)

    suspend fun deleteQuickReply(reply: QuickReply) = db.quickReplyDao().delete(reply)

    suspend fun updateQuickReply(reply: QuickReply) = db.quickReplyDao().update(reply)

    // ─── CALLS ───────────────────────────────────────────────────────────────

    fun getRecentCalls(): Flow<List<CallEntry>> = db.callDao().getRecentCalls()

    suspend fun logCall(entry: CallEntry): Long = db.callDao().insert(entry)

    suspend fun updateCallMoodAfter(id: Long, mood: MoodType) =
        db.callDao().updateMoodAfter(id, mood.name)

    // ─── CONTACTS ────────────────────────────────────────────────────────────

    suspend fun searchContacts(query: String): List<Contact> = withContext(Dispatchers.IO) {
        val contacts = mutableListOf<Contact>()
        val cursor: Cursor? = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.PHOTO_URI
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$query%"),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        )
        cursor?.use {
            val idIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
            val nameIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numberIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            val photoIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_URI)
            while (it.moveToNext()) {
                contacts.add(
                    Contact(
                        id = it.getString(idIdx) ?: "",
                        name = it.getString(nameIdx) ?: "Inconnu",
                        number = it.getString(numberIdx) ?: "",
                        photoUri = if (photoIdx >= 0) it.getString(photoIdx) else null
                    )
                )
            }
        }
        contacts.distinctBy { it.number }.take(30)
    }
}

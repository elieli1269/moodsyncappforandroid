package com.moodsync.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.moodsync.app.data.model.*
import com.moodsync.app.data.repository.MoodSyncRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class UiState(
    val currentMood: MoodType = MoodType.NEUTRAL,
    val recentMoods: List<MoodEntry> = emptyList(),
    val notifications: List<MoodNotification> = emptyList(),
    val unreadCount: Int = 0,
    val recentMessages: List<QuickMessage> = emptyList(),
    val recentCalls: List<CallEntry> = emptyList(),
    val quickReplies: List<QuickReply> = emptyList(),
    val contacts: List<Contact> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null
)

class MoodSyncViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = MoodSyncRepository(application)

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    // Search
    private val _contactQuery = MutableStateFlow("")
    val contactQuery = _contactQuery.asStateFlow()

    // Compose message
    private val _composeTarget = MutableStateFlow<Contact?>(null)
    val composeTarget = _composeTarget.asStateFlow()

    init {
        observeData()
    }

    private fun observeData() {
        // Moods
        viewModelScope.launch {
            repo.getAllMoods().collect { moods ->
                _state.update { it.copy(
                    recentMoods = moods,
                    currentMood = moods.firstOrNull()?.moodType ?: MoodType.NEUTRAL
                )}
            }
        }
        // Notifications
        viewModelScope.launch {
            repo.getAllNotifications().collect { notifs ->
                _state.update { it.copy(notifications = notifs) }
            }
        }
        // Unread count
        viewModelScope.launch {
            repo.getUnreadCount().collect { count ->
                _state.update { it.copy(unreadCount = count) }
            }
        }
        // Messages
        viewModelScope.launch {
            repo.getRecentMessages().collect { msgs ->
                _state.update { it.copy(recentMessages = msgs) }
            }
        }
        // Calls
        viewModelScope.launch {
            repo.getRecentCalls().collect { calls ->
                _state.update { it.copy(recentCalls = calls) }
            }
        }
        // Quick replies
        viewModelScope.launch {
            repo.getQuickReplies().collect { replies ->
                _state.update { it.copy(quickReplies = replies) }
            }
        }
        // Contact search
        viewModelScope.launch {
            _contactQuery
                .debounce(300)
                .filter { it.length >= 2 }
                .collect { query ->
                    val contacts = repo.searchContacts(query)
                    _state.update { it.copy(contacts = contacts) }
                }
        }
    }

    fun logMood(type: MoodType, note: String = "", energy: Int = 5, tags: List<String> = emptyList()) {
        viewModelScope.launch {
            repo.logMood(type, note, energy, tags)
        }
    }

    fun sendSms(recipient: String, number: String, content: String) {
        viewModelScope.launch {
            val mood = _state.value.currentMood
            repo.sendSms(recipient, number, content, mood)
        }
    }

    fun markAllRead() {
        viewModelScope.launch {
            repo.markAllNotifsAsRead()
        }
    }

    fun markNotifRead(id: Long) {
        viewModelScope.launch {
            repo.markNotifAsRead(id)
        }
    }

    fun searchContacts(query: String) {
        _contactQuery.value = query
    }

    fun setComposeTarget(contact: Contact?) {
        _composeTarget.value = contact
    }

    fun saveQuickReply(label: String, content: String) {
        viewModelScope.launch {
            repo.saveQuickReply(QuickReply(label = label, content = content))
        }
    }

    fun deleteQuickReply(reply: QuickReply) {
        viewModelScope.launch {
            repo.deleteQuickReply(reply)
        }
    }

    // Computed: mood stats for the week
    fun getWeeklyStats(): MoodStats {
        val moods = _state.value.recentMoods
        if (moods.isEmpty()) return MoodStats(MoodType.NEUTRAL, 5f, 0, 0, emptyList())

        val counts = moods.groupBy { it.moodType }.mapValues { it.value.size }
        val mostFrequent = counts.maxByOrNull { it.value }?.key ?: MoodType.NEUTRAL
        val avgEnergy = moods.map { it.energy }.average().toFloat()

        return MoodStats(
            mostFrequent = mostFrequent,
            averageEnergy = avgEnergy,
            totalEntries = moods.size,
            streak = calculateStreak(moods),
            weeklyData = emptyList()
        )
    }

    private fun calculateStreak(moods: List<MoodEntry>): Int {
        if (moods.isEmpty()) return 0
        var streak = 1
        val cal = java.util.Calendar.getInstance()
        val today = moods[0].timestamp
        cal.timeInMillis = today
        for (i in 1 until moods.size) {
            cal.timeInMillis -= 86_400_000L
            val dayBefore = moods.any {
                val c = java.util.Calendar.getInstance()
                c.timeInMillis = it.timestamp
                c.get(java.util.Calendar.DAY_OF_YEAR) == cal.get(java.util.Calendar.DAY_OF_YEAR)
            }
            if (dayBefore) streak++ else break
        }
        return streak
    }
}

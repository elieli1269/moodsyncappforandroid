package com.moodsync.app.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.moodsync.app.data.model.*
import com.moodsync.app.ui.MoodSyncViewModel
import com.moodsync.app.ui.UiState
import com.moodsync.app.ui.theme.MoodColors
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun StatsScreen(vm: MoodSyncViewModel, state: UiState) {
    val stats = remember(state.recentMoods) { vm.getWeeklyStats() }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MoodColors.Background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "Statistiques",
                style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Black),
                color = MoodColors.TextPrimary
            )
        }

        item { StatsOverviewRow(stats) }

        item {
            Text(
                "Distribution des humeurs",
                style = MaterialTheme.typography.titleMedium,
                color = MoodColors.TextSecondary
            )
        }

        item { MoodDistributionChart(state.recentMoods) }

        item {
            Text(
                "Humeurs vs Activités",
                style = MaterialTheme.typography.titleMedium,
                color = MoodColors.TextSecondary
            )
        }

        item { MoodActivityCorrelation(state) }

        item {
            Text(
                "Réponses rapides",
                style = MaterialTheme.typography.titleMedium,
                color = MoodColors.TextSecondary
            )
        }

        item { QuickRepliesManager(vm, state) }
    }
}

@Composable
private fun StatsOverviewRow(stats: MoodStats) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        StatCard(
            modifier = Modifier.weight(1f),
            emoji = stats.mostFrequent.emoji,
            label = "Humeur dominante",
            value = stats.mostFrequent.label,
            color = Color(stats.mostFrequent.color)
        )
        StatCard(
            modifier = Modifier.weight(1f),
            emoji = "⚡",
            label = "Énergie moyenne",
            value = String.format("%.1f/10", stats.averageEnergy),
            color = MoodColors.Warning
        )
    }
    Spacer(Modifier.height(4.dp))
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        StatCard(
            modifier = Modifier.weight(1f),
            emoji = "📝",
            label = "Total logs",
            value = "${stats.totalEntries}",
            color = MoodColors.Info
        )
        StatCard(
            modifier = Modifier.weight(1f),
            emoji = "🔥",
            label = "Streak",
            value = "${stats.streak} jours",
            color = MoodColors.Error
        )
    }
}

@Composable
private fun StatCard(modifier: Modifier, emoji: String, label: String, value: String, color: Color) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MoodColors.Surface),
        border = BorderStroke(1.dp, color.copy(alpha = 0.2f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(emoji, fontSize = 24.sp)
            Text(value, style = MaterialTheme.typography.titleLarge, color = color, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MoodColors.TextSecondary)
        }
    }
}

@Composable
private fun MoodDistributionChart(moods: List<MoodEntry>) {
    if (moods.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp)
                .background(MoodColors.Surface, RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("Aucune donnée", color = MoodColors.TextMuted)
        }
        return
    }

    val counts = MoodType.values().associateWith { mood ->
        moods.count { it.moodType == mood }
    }
    val maxCount = counts.values.maxOrNull()?.takeIf { it > 0 } ?: 1

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MoodColors.Surface, RoundedCornerShape(16.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        counts.entries.filter { it.value > 0 }.sortedByDescending { it.value }.forEach { (mood, count) ->
            val color = Color(mood.color)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(mood.emoji, fontSize = 20.sp, modifier = Modifier.width(28.dp))
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(28.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(count.toFloat() / maxCount)
                            .clip(RoundedCornerShape(6.dp))
                            .background(color.copy(alpha = 0.6f))
                    )
                }
                Text(
                    "$count",
                    style = MaterialTheme.typography.labelLarge,
                    color = color,
                    modifier = Modifier.width(24.dp)
                )
            }
        }
    }
}

@Composable
private fun MoodActivityCorrelation(state: UiState) {
    val smsCount = state.recentMessages.size
    val callCount = state.recentCalls.size
    val notifCount = state.notifications.size

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MoodColors.Surface, RoundedCornerShape(16.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        listOf(
            Triple("💬 SMS envoyés", smsCount, MoodColors.Info),
            Triple("📞 Appels enregistrés", callCount, MoodColors.Success),
            Triple("🔔 Notifications reçues", notifCount, MoodColors.Secondary)
        ).forEach { (label, count, color) ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(label, style = MaterialTheme.typography.bodyMedium, color = MoodColors.TextSecondary)
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = color.copy(alpha = 0.15f)
                ) {
                    Text(
                        "$count",
                        style = MaterialTheme.typography.titleMedium,
                        color = color,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickRepliesManager(vm: MoodSyncViewModel, state: UiState) {
    var newLabel by remember { mutableStateOf("") }
    var newContent by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MoodColors.Surface, RoundedCornerShape(16.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Réponses rapides", style = MaterialTheme.typography.titleMedium, color = MoodColors.TextPrimary)
            TextButton(onClick = { showAdd = !showAdd }) {
                Text(if (showAdd) "Annuler" else "+ Ajouter", color = MoodColors.Primary)
            }
        }

        if (showAdd) {
            OutlinedTextField(
                value = newLabel,
                onValueChange = { newLabel = it },
                label = { Text("Étiquette (ex: Occupé)", color = MoodColors.TextSecondary) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MoodColors.Primary,
                    unfocusedBorderColor = MoodColors.TextMuted,
                    focusedTextColor = MoodColors.TextPrimary,
                    unfocusedTextColor = MoodColors.TextPrimary
                )
            )
            OutlinedTextField(
                value = newContent,
                onValueChange = { newContent = it },
                label = { Text("Message", color = MoodColors.TextSecondary) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MoodColors.Primary,
                    unfocusedBorderColor = MoodColors.TextMuted,
                    focusedTextColor = MoodColors.TextPrimary,
                    unfocusedTextColor = MoodColors.TextPrimary
                )
            )
            Button(
                onClick = {
                    if (newLabel.isNotBlank() && newContent.isNotBlank()) {
                        vm.saveQuickReply(newLabel, newContent)
                        newLabel = ""
                        newContent = ""
                        showAdd = false
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = MoodColors.Primary),
                modifier = Modifier.align(Alignment.End)
            ) {
                Text("Sauvegarder", color = Color.Black)
            }
        }

        if (state.quickReplies.isEmpty() && !showAdd) {
            Text(
                "Aucune réponse rapide. Ajoutez-en pour les utiliser lors de l'envoi de messages.",
                style = MaterialTheme.typography.bodyMedium,
                color = MoodColors.TextMuted
            )
        } else {
            state.quickReplies.forEach { reply ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(reply.label, style = MaterialTheme.typography.labelLarge, color = MoodColors.Primary)
                        Text(reply.content, style = MaterialTheme.typography.bodyMedium, color = MoodColors.TextSecondary, maxLines = 1)
                    }
                    IconButton(
                        onClick = { vm.deleteQuickReply(reply) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Text("🗑️", fontSize = 16.sp)
                    }
                }
                HorizontalDivider(color = MoodColors.TextMuted.copy(alpha = 0.2f))
            }
        }
    }
}

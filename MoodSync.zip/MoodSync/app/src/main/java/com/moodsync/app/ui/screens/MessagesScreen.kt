package com.moodsync.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.moodsync.app.data.model.*
import com.moodsync.app.ui.MoodSyncViewModel
import com.moodsync.app.ui.UiState
import com.moodsync.app.ui.theme.MoodColors
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun MessagesScreen(vm: MoodSyncViewModel, state: UiState) {
    var showCompose by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MoodColors.Background)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Messages",
                style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Black),
                color = MoodColors.TextPrimary
            )
            FloatingActionButton(
                onClick = { showCompose = true },
                containerColor = MoodColors.Primary,
                modifier = Modifier.size(44.dp)
            ) {
                Icon(Icons.Filled.Edit, contentDescription = "Nouveau message", tint = Color.Black)
            }
        }

        if (state.recentMessages.isEmpty()) {
            EmptyState(
                icon = "💬",
                title = "Aucun message envoyé",
                subtitle = "Composez un SMS directement depuis MoodSync"
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(state.recentMessages) { msg ->
                    SentMessageItem(msg)
                }
            }
        }
    }

    // Compose sheet
    if (showCompose) {
        ComposeMessageSheet(
            vm = vm,
            state = state,
            onDismiss = { showCompose = false }
        )
    }
}

@Composable
private fun SentMessageItem(msg: QuickMessage) {
    val mood = try { MoodType.fromName(msg.moodAtSend) } catch (e: Exception) { MoodType.NEUTRAL }
    val moodColor = Color(mood.color)
    val fmt = SimpleDateFormat("dd MMM · HH:mm", Locale.FRANCE)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MoodColors.Surface, RoundedCornerShape(16.dp))
            .padding(14.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            if (msg.sent) "✅" else "❌",
            fontSize = 20.sp,
            modifier = Modifier.padding(top = 2.dp)
        )
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(msg.recipient.ifBlank { msg.recipientNumber }, style = MaterialTheme.typography.titleMedium, color = MoodColors.TextPrimary)
            Text(msg.content, style = MaterialTheme.typography.bodyMedium, color = MoodColors.TextSecondary, maxLines = 2)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier
                        .background(moodColor.copy(alpha = 0.1f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(mood.emoji, fontSize = 12.sp)
                    Text(mood.label, style = MaterialTheme.typography.labelSmall, color = moodColor)
                }
                Text(fmt.format(Date(msg.timestamp)), style = MaterialTheme.typography.labelSmall, color = MoodColors.TextMuted)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ComposeMessageSheet(
    vm: MoodSyncViewModel,
    state: UiState,
    onDismiss: () -> Unit
) {
    var recipient by remember { mutableStateOf("") }
    var recipientNumber by remember { mutableStateOf("") }
    var messageText by remember { mutableStateOf("") }
    var contactQuery by remember { mutableStateOf("") }
    var showContacts by remember { mutableStateOf(false) }
    var selectedContact by remember { mutableStateOf<Contact?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MoodColors.Surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                "Nouveau SMS",
                style = MaterialTheme.typography.headlineMedium,
                color = MoodColors.TextPrimary
            )

            // Recipient search
            OutlinedTextField(
                value = contactQuery,
                onValueChange = {
                    contactQuery = it
                    vm.searchContacts(it)
                    showContacts = it.length >= 2
                    if (selectedContact != null && it != selectedContact!!.name) {
                        selectedContact = null
                        recipient = ""
                        recipientNumber = ""
                    }
                },
                label = { Text("À : nom ou numéro", color = MoodColors.TextSecondary) },
                leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null, tint = MoodColors.TextMuted) },
                trailingIcon = {
                    if (contactQuery.isNotBlank()) {
                        IconButton(onClick = {
                            contactQuery = ""
                            selectedContact = null
                            recipient = ""
                            recipientNumber = ""
                            showContacts = false
                        }) {
                            Icon(Icons.Filled.Clear, contentDescription = null, tint = MoodColors.TextMuted)
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MoodColors.Primary,
                    unfocusedBorderColor = MoodColors.TextMuted,
                    focusedTextColor = MoodColors.TextPrimary,
                    unfocusedTextColor = MoodColors.TextPrimary
                )
            )

            // Contact suggestions
            AnimatedVisibility(visible = showContacts && state.contacts.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MoodColors.SurfaceVariant, RoundedCornerShape(12.dp))
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    state.contacts.take(5).forEach { contact ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedContact = contact
                                    contactQuery = contact.name
                                    recipient = contact.name
                                    recipientNumber = contact.number
                                    showContacts = false
                                }
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = MoodColors.Primary.copy(alpha = 0.15f),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        contact.name.firstOrNull()?.uppercase() ?: "?",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MoodColors.Primary
                                    )
                                }
                            }
                            Column {
                                Text(contact.name, style = MaterialTheme.typography.titleMedium, color = MoodColors.TextPrimary)
                                Text(contact.number, style = MaterialTheme.typography.bodyMedium, color = MoodColors.TextSecondary)
                            }
                        }
                    }
                }
            }

            // Quick replies
            if (state.quickReplies.isNotEmpty()) {
                Text("Réponses rapides", style = MaterialTheme.typography.labelLarge, color = MoodColors.TextSecondary)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(state.quickReplies) { qr ->
                        FilterChip(
                            selected = messageText == qr.content,
                            onClick = { messageText = qr.content },
                            label = { Text(qr.label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MoodColors.Primary.copy(alpha = 0.2f),
                                selectedLabelColor = MoodColors.Primary
                            )
                        )
                    }
                }
            }

            // Mood context
            val mood = state.currentMood
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(mood.color).copy(alpha = 0.08f), RoundedCornerShape(10.dp))
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(mood.emoji, fontSize = 20.sp)
                Text(
                    "Envoi en mode ${mood.label}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(mood.color)
                )
            }

            // Message text
            OutlinedTextField(
                value = messageText,
                onValueChange = { messageText = it },
                label = { Text("Message", color = MoodColors.TextSecondary) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp),
                maxLines = 5,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MoodColors.Primary,
                    unfocusedBorderColor = MoodColors.TextMuted,
                    focusedTextColor = MoodColors.TextPrimary,
                    unfocusedTextColor = MoodColors.TextPrimary
                )
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.weight(1f),
                    border = BorderStroke(1.dp, MoodColors.TextMuted)
                ) {
                    Text("Annuler", color = MoodColors.TextSecondary)
                }
                Button(
                    onClick = {
                        val number = recipientNumber.ifBlank { contactQuery }
                        if (number.isNotBlank() && messageText.isNotBlank()) {
                            vm.sendSms(recipient.ifBlank { number }, number, messageText)
                            onDismiss()
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MoodColors.Primary),
                    enabled = messageText.isNotBlank() && (recipientNumber.isNotBlank() || contactQuery.isNotBlank())
                ) {
                    Icon(Icons.Filled.Send, contentDescription = null, tint = Color.Black)
                    Spacer(Modifier.width(8.dp))
                    Text("Envoyer", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
